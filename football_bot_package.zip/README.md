# Telegram Football Match Predictor Bot

This bot predicts match outcome, over/under 2.5 goals, and both teams to score.

## Hosting Steps

1. Upload to GitHub
2. Deploy on [Render.com](https://render.com)
3. Set `BOT_TOKEN` as environment variable
4. Add UptimeRobot monitor to keep it live

Bot starts with `/start`
